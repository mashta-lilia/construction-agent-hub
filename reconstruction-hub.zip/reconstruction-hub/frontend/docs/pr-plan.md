# Розбивка на PR

Правило 4: 200 рядків диффу — ціль, 400 — жорстка стеля. Цей внесок цілком —
близько 5000 рядків, тому влити його одним PR не можна. Порядок нижче тримає
кожен PR самодостатнім: після кожного `npm run lint && npm run typecheck &&
npm run build` зелені.

| #   | PR                                                                       | Гілка                      | ~рядків |
| --- | ------------------------------------------------------------------------ | -------------------------- | ------- |
| 1   | Каркас: monorepo, конфіги, CI, pre-commit, порожній Vite-застосунок      | `chore/frontend-scaffold`  | 380     |
| 2   | Типи домену                                                              | `feat/domain-types`        | 400     |
| 3   | Мок-дані, частина 1: проєкти, інженери, листи, inbox-сіди                | `feat/mock-data-core`      | 320     |
| 4   | Мок-дані, частина 2: сценарії заміни + фабрики артефактів                | `feat/mock-data-scenarios` | 390     |
| 5   | Словники en/uk                                                           | `feat/i18n-dictionaries`   | 340     |
| 6   | `useI18n`, провайдер, cookie локалі                                      | `feat/i18n-provider`       | 180     |
| 7   | Токени теми: `globals.css` + `next-themes` + smoke-екран                 | `feat/theme-tokens`        | 400     |
| 8   | Примітиви, частина 1: Button, Badge, Card, Alert, Input, Textarea, Label | `feat/ui-primitives-base`  | 380     |
| 9   | Примітиви, частина 2: Dialog, Sheet, Select                              | `feat/ui-overlays`         | 390     |
| 10  | Примітиви, частина 3: DropdownMenu, Popover, Tooltip, Tabs, Table, решта | `feat/ui-primitives-rest`  | 400     |
| 11  | Утиліти: адреса проєкту, дедлайни, документи, навігація                  | `feat/lib-utils`           | 260     |
| 12  | Спільні компоненти + `useSortableData`                                   | `feat/common-components`   | 240     |

Далі порт екранів — по одній фічі на PR, у порядку з `migration-checklist.md`.
Великі компоненти (`SubstitutionFlow` — 322 рядки, `DocumentationTab` — 198)
розбиваються на підкомпоненти, кожен зі своїм PR, щоб не пробити стелю.

Мок-дані і словники — це дані, а не логіка, тож ревʼю там швидке; якщо команда
готова, PR 3–5 можна помітити як `data-only` і дивитися вибірково.
