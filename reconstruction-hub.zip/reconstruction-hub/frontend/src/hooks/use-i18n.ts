'use client';

import { useContext } from 'react';

import { I18nContext, type I18nContextValue } from '@/components/providers/i18n-provider';

/**
 * Access the active locale plus `t()` / `L()`.
 *
 * Direct replacement for the prototype's `useI18n`, with two differences: the
 * dictionaries are no longer inlined next to the hook, and `t()` only accepts
 * keys that exist in the `en` dictionary.
 */
export function useI18n(): I18nContextValue {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used inside <I18nProvider>');
  }
  return context;
}
