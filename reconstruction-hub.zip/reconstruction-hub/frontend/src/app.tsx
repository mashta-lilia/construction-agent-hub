import { HardHat, Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useI18n } from '@/hooks/use-i18n';
import { formatBudget } from '@/lib/format';
import { isLocale, LOCALES } from '@/lib/i18n-config';
import { getScenario, PROJECTS } from '@/lib/mock-data';
import type { RiskLevel } from '@/types';

/* =============================================================================
 * TEMPORARY foundation smoke test — replaced by features/dashboard.
 * ---------------------------------------------------------------------------
 * Exercises everything the feature work depends on, so a regression shows up
 * here first: semantic tokens in both themes, `next-themes` without a flash,
 * the locale cookie surviving a reload, typed `t()` / `L()`, the mock data, and
 * the Radix primitives that replaced the hand-rolled ones (portalled Select,
 * Dialog focus trap, Tooltip, toasts with undo).
 * ========================================================================== */

const RISK_VARIANT: Record<RiskLevel, 'success' | 'warning' | 'danger'> = {
  green: 'success',
  amber: 'warning',
  red: 'danger',
};

export function App() {
  const { t, L, locale, setLocale } = useI18n();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const demoProject = PROJECTS[0];
  const scenario = demoProject ? getScenario(demoProject.id) : null;

  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <HardHat className="size-5" />
          </span>
          <div>
            <h1 className="text-lg font-semibold text-foreground">REHUB</h1>
            <p className="text-sm text-muted-foreground">{t('brand.tagline')}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Select
            value={locale}
            onValueChange={(next) => {
              if (isLocale(next)) setLocale(next);
            }}
          >
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LOCALES.map((code) => (
                <SelectItem key={code} value={code}>
                  {code === 'en' ? 'English' : 'Українська'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  setTheme(isDark ? 'light' : 'dark');
                }}
                aria-label={t(isDark ? 'theme.dark' : 'theme.light')}
              >
                {isDark ? <Sun /> : <Moon />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t(isDark ? 'theme.dark' : 'theme.light')}</TooltipContent>
          </Tooltip>
        </div>
      </header>

      <section className="mt-8 flex flex-wrap items-center gap-2">
        <Badge variant="info">{t('badge.newSupplierEmail')}</Badge>
        <Badge variant="success">{t('status.completed')}</Badge>
        <Badge variant="warning">{t('status.onHold')}</Badge>
        <Badge variant="danger">{t('status.audit')}</Badge>
        <Badge variant="outline">{t('status.planning')}</Badge>

        <Dialog>
          <DialogTrigger asChild>
            <Button variant="primary" size="sm" className="ml-auto">
              {t('action.view')}
            </Button>
          </DialogTrigger>
          <DialogContent size="lg">
            <DialogHeader>
              <DialogTitle>{scenario ? L(scenario.verdict.title) : t('action.view')}</DialogTitle>
              <DialogDescription>{scenario ? L(scenario.verdict.desc) : null}</DialogDescription>
            </DialogHeader>
            <div className="px-5 py-4 text-sm text-foreground-muted">
              {scenario ? (
                <ul className="space-y-1.5">
                  {scenario.table1.map((row) => (
                    <li key={L(row.crit)} className="flex items-center justify-between gap-4">
                      <span>{L(row.crit)}</span>
                      <Badge variant={row.status === 'violation' ? 'danger' : 'success'}>
                        {L(row.proposal)}
                      </Badge>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
            <DialogFooter>
              <Button
                variant="primary"
                onClick={() =>
                  toast.success(t('toast.reportSaved'), {
                    action: { label: t('toast.undo'), onClick: () => undefined },
                  })
                }
              >
                {t('action.download')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </section>

      <Card className="mt-6 overflow-hidden">
        <CardHeader>
          <CardTitle>{t('nav.projects')}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-muted">
                <TableHead>{t('col.name')}</TableHead>
                <TableHead>{t('col.status')}</TableHead>
                <TableHead>{t('risk.label')}</TableHead>
                <TableHead className="text-right">{t('col.budget')}</TableHead>
                <TableHead>{t('card.deadline')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {PROJECTS.map((project) => (
                <TableRow key={project.id}>
                  <TableCell>
                    <div className="font-medium text-foreground">{L(project.name)}</div>
                    <div className="text-xs text-foreground-faint">{project.id}</div>
                  </TableCell>
                  <TableCell className="text-foreground-muted">
                    {t(`status.${project.statusKey}`)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={RISK_VARIANT[project.risk]}>{t(`risk.${project.risk}`)}</Badge>
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-foreground">
                    {formatBudget(project.budget, t)}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{L(project.deadline)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <p className="mt-6 text-xs text-foreground-faint">
        Foundation smoke test — replaced by the dashboard feature.
      </p>
    </main>
  );
}
