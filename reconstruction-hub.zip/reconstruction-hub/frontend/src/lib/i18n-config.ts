/* =============================================================================
 * Locale configuration.
 * ---------------------------------------------------------------------------
 * Kept free of imports so it can be pulled into both the server layout and
 * client components without dragging the dictionaries along.
 * ========================================================================== */

export const LOCALES = ['en', 'uk'] as const;

export type Locale = (typeof LOCALES)[number];

export const DEFAULT_LOCALE: Locale = 'en';

/**
 * The active locale is stored in a cookie rather than `localStorage` so the
 * backend can read it too: report exports and supplier reply drafts have to be
 * generated in the language the engineer is working in.
 */
export const LOCALE_COOKIE = 'rehub_locale';

/** One year. */
export const LOCALE_COOKIE_MAX_AGE = 60 * 60 * 24 * 365;

export function isLocale(value: unknown): value is Locale {
  return typeof value === 'string' && (LOCALES as readonly string[]).includes(value);
}

/** Reads the locale cookie, falling back to the default outside the browser. */
export function readLocaleCookie(): Locale {
  if (typeof document === 'undefined') return DEFAULT_LOCALE;

  const match = new RegExp(`(?:^|; )${LOCALE_COOKIE}=([^;]*)`).exec(document.cookie);
  const value = match?.[1] ? decodeURIComponent(match[1]) : null;
  return isLocale(value) ? value : DEFAULT_LOCALE;
}

export function writeLocaleCookie(locale: Locale): void {
  document.cookie = `${LOCALE_COOKIE}=${locale}; path=/; max-age=${String(LOCALE_COOKIE_MAX_AGE)}; samesite=lax`;
}
