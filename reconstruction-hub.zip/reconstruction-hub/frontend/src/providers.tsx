import { ThemeProvider } from 'next-themes';
import type { ReactNode } from 'react';

import { I18nProvider } from '@/components/providers/i18n-provider';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';

/**
 * Single place where cross-cutting context is mounted.
 *
 * `next-themes` replaces the prototype's hand-rolled theme context and the
 * `html.dark` class juggling; it reads the same `rehub_theme` key that the
 * inline script in `index.html` uses, so the class is already correct before
 * the bundle runs and there is no flash of the wrong theme.
 */
export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem storageKey="rehub_theme">
      <I18nProvider>
        <TooltipProvider>{children}</TooltipProvider>
        <Toaster />
      </I18nProvider>
    </ThemeProvider>
  );
}
