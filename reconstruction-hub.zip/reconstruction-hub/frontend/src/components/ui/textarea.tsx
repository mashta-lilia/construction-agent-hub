import type { ComponentProps } from 'react';

import { cn } from '@/lib/utils';

function Textarea({ className, ...props }: ComponentProps<'textarea'>) {
  return (
    <textarea
      data-slot="textarea"
      className={cn(
        'w-full rounded-md border border-input bg-card px-3 py-2 text-sm leading-relaxed text-foreground outline-none transition-colors placeholder:text-foreground-faint focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50',
        'aria-invalid:border-danger-border',
        className,
      )}
      {...props}
    />
  );
}

export { Textarea };
