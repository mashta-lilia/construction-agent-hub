import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import type { ComponentProps } from 'react';

import { cn } from '@/lib/utils';

/**
 * Variants mirror the prototype's `Button` one-to-one, re-expressed in tokens.
 * `default` is the graphite button (`bg-slate-900` in the prototype -> `bg-ink`);
 * `primary` is the brand blue. Keeping both names avoids touching call sites.
 */
const buttonVariants = cva(
  "inline-flex shrink-0 items-center justify-center gap-1.5 whitespace-nowrap rounded-md font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: 'bg-ink text-ink-foreground hover:bg-ink-hover',
        primary: 'bg-primary text-primary-foreground hover:bg-primary-hover',
        destructive: 'bg-danger text-white hover:bg-danger-hover',
        outline: 'border border-input bg-card text-foreground-muted hover:bg-muted',
        secondary: 'bg-secondary text-secondary-foreground hover:bg-muted-strong',
        ghost: 'text-muted-foreground hover:bg-muted-strong hover:text-foreground',
        link: 'text-info-foreground underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-9 px-4 text-sm',
        sm: 'h-8 px-3 text-xs',
        lg: 'h-10 px-5 text-sm',
        icon: 'size-9',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  },
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ComponentProps<'button'> & VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : 'button';
  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}

export { Button, buttonVariants };
