'use client';

import { useTheme } from 'next-themes';
import { Toaster as Sonner, type ToasterProps } from 'sonner';

/**
 * Replaces the prototype's `ToastProvider` / `useToast`. The undo flows become
 * `toast.success(message, { action: { label, onClick } })`.
 */
function Toaster(props: ToasterProps) {
  const { theme = 'system' } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps['theme']}
      className="toaster group"
      position="bottom-right"
      style={
        {
          '--normal-bg': 'var(--card)',
          '--normal-text': 'var(--foreground)',
          '--normal-border': 'var(--border)',
          '--success-bg': 'var(--success-subtle)',
          '--success-text': 'var(--success-foreground)',
          '--error-bg': 'var(--danger-subtle)',
          '--error-text': 'var(--danger-foreground)',
        } as React.CSSProperties
      }
      {...props}
    />
  );
}

export { Toaster };
