import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import type { ComponentProps } from 'react';

import { cn } from '@/lib/utils';

/** `blue` / `green` / `amber` / `red` in the prototype become semantic names. */
const badgeVariants = cva(
  'inline-flex w-fit shrink-0 items-center gap-1 whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset [&_svg]:size-3',
  {
    variants: {
      variant: {
        default: 'bg-muted-strong text-foreground-muted ring-border',
        info: 'bg-info-subtle text-info-foreground ring-info-border',
        success: 'bg-success-subtle text-success-foreground ring-success-border',
        warning: 'bg-warning-subtle text-warning-foreground ring-warning-border',
        danger: 'bg-danger-subtle text-danger-foreground ring-danger-border',
        outline: 'bg-card text-muted-foreground ring-input',
      },
    },
    defaultVariants: { variant: 'default' },
  },
);

function Badge({
  className,
  variant,
  asChild = false,
  ...props
}: ComponentProps<'span'> & VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : 'span';
  return (
    <Comp data-slot="badge" className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
