import { createContext, useCallback, useMemo, useState, type ReactNode } from 'react';

import { resolveBilingual } from '@/lib/bilingual';
import { DICTIONARIES, type TranslationKey } from '@/lib/dictionaries';
import { readLocaleCookie, writeLocaleCookie, type Locale } from '@/lib/i18n-config';
import type { Localizable, TranslationVars } from '@/types';

export interface I18nContextValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  /** Translates a dictionary key, interpolating `{name}` placeholders. */
  t: (key: TranslationKey, vars?: TranslationVars) => string;
  /** Resolves a bilingual value (or passes a plain string through). */
  L: (value: Localizable) => string;
}

export const I18nContext = createContext<I18nContextValue | null>(null);

interface I18nProviderProps {
  children: ReactNode;
  /** Overrides the cookie; useful in tests and stories. */
  initialLocale?: Locale;
}

export function I18nProvider({ children, initialLocale }: I18nProviderProps) {
  const [locale, setLocaleState] = useState<Locale>(() => initialLocale ?? readLocaleCookie());

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    /**
     * The cookie is not only a client-side preference store: the backend reads
     * it to know which language to render report exports and reply drafts in.
     */
    writeLocaleCookie(next);
    document.documentElement.lang = next;
  }, []);

  /**
   * The dictionaries themselves are module-level constants, so nothing is
   * rebuilt per render — this memo only rebinds `t` / `L` when the locale
   * actually changes.
   */
  const value = useMemo<I18nContextValue>(() => {
    const dictionary = DICTIONARIES[locale];

    const t = (key: TranslationKey, vars?: TranslationVars): string => {
      let result = dictionary[key];
      if (vars) {
        for (const [name, replacement] of Object.entries(vars)) {
          result = result.split(`{${name}}`).join(String(replacement));
        }
      }
      return result;
    };

    return {
      locale,
      setLocale,
      t,
      L: (input: Localizable) => resolveBilingual(input, locale),
    };
  }, [locale, setLocale]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}
