import { Info } from 'lucide-react';

import { Alert, AlertDescription } from '@/components/ui/alert';

/**
 * Required by the spec's risk table: an automated verdict may be wrong, so it is
 * always presented as a recommendation and the engineer confirms personally.
 * Render this next to every AI-produced verdict, report and reply draft.
 */
export function RecommendationNotice({ text }: { text: string }) {
  return (
    <Alert variant="info">
      <Info />
      <AlertDescription>{text}</AlertDescription>
    </Alert>
  );
}
