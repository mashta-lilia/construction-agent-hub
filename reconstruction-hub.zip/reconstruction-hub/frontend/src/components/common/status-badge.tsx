'use client';

import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/hooks/use-i18n';
import type { ProjectStage, RiskLevel } from '@/types';

/** Same mapping the prototype used, with semantic variant names. */
const STAGE_VARIANT: Record<ProjectStage, 'default' | 'info' | 'success' | 'warning'> = {
  planning: 'default',
  inProgress: 'info',
  audit: 'warning',
  onHold: 'warning',
  completed: 'success',
};

export function StatusBadge({ status }: { status: ProjectStage }) {
  const { t } = useI18n();
  return <Badge variant={STAGE_VARIANT[status]}>{t(`status.${status}`)}</Badge>;
}

const RISK_VARIANT: Record<RiskLevel, 'success' | 'warning' | 'danger'> = {
  green: 'success',
  amber: 'warning',
  red: 'danger',
};

export function RiskBadge({ risk }: { risk: RiskLevel }) {
  const { t } = useI18n();
  return <Badge variant={RISK_VARIANT[risk]}>{t(`risk.${risk}`)}</Badge>;
}
