import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';

import { cn } from '@/lib/utils';

interface InfoCardProps {
  icon: LucideIcon;
  label: string;
  value: ReactNode;
  /** Secondary line under the value, e.g. "recalculated" after a substitution. */
  sub?: ReactNode;
  className?: string;
}

/** Compact metric tile used across the project card header. */
export function InfoCard({ icon: Icon, label, value, sub, className }: InfoCardProps) {
  return (
    <div
      className={cn(
        'flex items-start gap-3 rounded-lg border border-border bg-card px-3.5 py-3',
        className,
      )}
    >
      <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-muted-strong text-muted-foreground">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0">
        <div className="text-xs font-medium text-muted-foreground">{label}</div>
        <div className="truncate text-sm font-semibold text-foreground">{value}</div>
        {sub ? <div className="mt-0.5 text-xs text-foreground-faint">{sub}</div> : null}
      </div>
    </div>
  );
}
