# RECONSTRUCTION HUB

AI-агент аналізу заміни будівельних матеріалів у проєктах відновлення.

Monorepo за правилом 8: фронтенд і бекенд в одному репозиторії, без Nx/Turborepo.

```
frontend/   React + TypeScript + Vite  (цей внесок)
backend/    FastAPI + PostgreSQL/pgvector  (окрема команда)
docs/       спільна документація рівня репозиторію
```

Правила розробки — у `RULES.md` в корені. Найважливіше з них для щоденної роботи:
гілка живе не довше 2 днів, PR до 400 рядків диффу, лінт/типи/тести зелені,
вердикт формує детермінований код, а не LLM.

## Стан робіт

| Частина | Стан |
| --- | --- |
| `frontend/` | фундамент і примітиви готові, екрани продукту — в роботі. Деталі: `frontend/README.md` |
| `backend/` | не розпочато |

## Запуск фронтенда

```bash
cd frontend
npm install
npm run dev
```

## Гейти

```bash
pre-commit install && pre-commit run --all-files   # один менеджер хуків на весь репо
cd frontend && npm run lint && npm run typecheck && npm run build
```

CI (`.github/workflows/`): `frontend.yml` — лінт, типи і збірка паралельно;
`pr-size.yml` — стеля 400 рядків диффу за правилом 4.

Захист `main` налаштовується в самому репозиторії: require PR, 1 approval,
require status checks, без прямого пушу.
